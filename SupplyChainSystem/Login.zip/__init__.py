# load LoginCongfig
default_app_config = 'Login.apps.LoginConfig'